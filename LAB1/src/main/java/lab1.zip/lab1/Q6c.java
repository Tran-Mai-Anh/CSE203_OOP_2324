/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab1;

/**
 *
 * @author maianhtran
 */
import java.util.*;

public class Q6c {

    static Scanner reader = new Scanner(System.in);

    public static void main(String[] agrs) {
        String a = reader.nextLine();
        String b = reader.nextLine();
        String s = (new StringBuilder()).append(a).append(b).toString();
        System.out.print(s);
    }

}
