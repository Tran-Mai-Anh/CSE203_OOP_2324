/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q2;

/**
 *
 * @author maianhtran
 */
public class ResortPriceCalculator {
    public static void main(String[]args){
        new ResortForm().setVisible(true);
    }
}


