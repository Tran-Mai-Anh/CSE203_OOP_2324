/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Q3;

import java.util.Scanner;

/**
 *
 * @author maianhtran
 */
public class CDStore {

    public static void main(String[] args) {
        new CDListForm().setVisible(true);
        
    }

}
