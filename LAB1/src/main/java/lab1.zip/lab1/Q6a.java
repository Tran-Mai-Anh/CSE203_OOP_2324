/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab1;

/**
 *
 * @author maianhtran
 */
import java.util.*;

public class Q6a {

    static Scanner reader = new Scanner(System.in);

    public static void main(String[] args) {
        String n = reader.nextLine();
        System.out.println(" The length of the string: " + n.length());

    }
}
